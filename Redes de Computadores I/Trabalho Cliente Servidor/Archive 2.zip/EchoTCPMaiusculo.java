/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */


import java.io.*; 
import java.net.*; 
import java.util.*;

public class EchoTCPMaiusculo implements Runnable { 

    Socket socketConexao;
    
    public void setSocketConexao (Socket s) {
        socketConexao = s;
    }
    
    public void run()
    { 
      String fraseCliente; 
      String fraseEmMaiusculas; 


      try{
           BufferedReader doCliente = 
              new BufferedReader(new
              InputStreamReader(socketConexao.getInputStream())); 

           DataOutputStream  paraCliente = 
             new DataOutputStream(socketConexao.getOutputStream()); 

           fraseCliente= doCliente.readLine(); 

           // System.out.println("Do Cliente: " + fraseCliente);

           fraseEmMaiusculas= fraseCliente.toUpperCase() + '\n'; 

           // System.out.println("Para Cliente: " + fraseEmMaiusculas);
           System.out.println("Cliente com IP =" + socketConexao.getInetAddress() 
                   + " na porta " + socketConexao.getPort() + 
                   " enviou: " + fraseCliente); 

           paraCliente.writeBytes(fraseEmMaiusculas);
      } catch (IOException ex1) {
              
          }
      }
}
              



