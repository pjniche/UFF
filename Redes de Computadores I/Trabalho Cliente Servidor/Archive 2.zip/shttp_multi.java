/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */

import java.io.*;
import java.net.*;
import java.util.*;
    
 public class shttp_multi {
	
    public static void main(String argv[]) throws Exception
	{
            
            ServerSocket listenSocket = new ServerSocket(6789);
                
            while (true) {
                System.out.println("Servidor com IP =" + listenSocket.getInetAddress() 
                   + " na porta 6789 aguarda cliente");
		Socket cs = listenSocket.accept();
                TrataCliente tratacliente = new TrataCliente();
                tratacliente.setSocket(cs);
                Thread threadDoCliente = new Thread(tratacliente);
                threadDoCliente.start();
            }
        }
    
}
        



