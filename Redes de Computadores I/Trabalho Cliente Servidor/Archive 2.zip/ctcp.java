/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */

import java.io.*; 
import java.net.*; 

public class ctcp { 

    public static void main(String argv[]) throws Exception 
    { 
        String frase; 
        String fraseModificada; 

        BufferedReader doUsuario = 
          new BufferedReader(new InputStreamReader(System.in)); 

        Socket socketCliente = new Socket("localhost", 6789); 
        
        System.out.println("Cliente com IP =" + socketCliente.getLocalAddress() 
                   + " na porta " + socketCliente.getLocalPort()
                   + ", conectado ao Servidor com IP =" + socketCliente.getInetAddress() 
                   + " na porta " + socketCliente.getPort());

        DataOutputStream paraServidor = 
          new DataOutputStream(socketCliente.getOutputStream()); 

        BufferedReader doServidor = 
          new BufferedReader(new
          InputStreamReader(socketCliente.getInputStream())); 

        frase = doUsuario.readLine(); 

        paraServidor.writeBytes(frase + '\n'); 

        fraseModificada = doServidor.readLine(); 

        System.out.println("Do Servidor: " + fraseModificada); 

        socketCliente.close(); 
                   
    } 
} 

