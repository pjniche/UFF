/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */


import java.io.*; 
import java.net.*; 
  
public class sudp { 
  public static void main(String args[]) throws Exception 
    { 
  
      DatagramSocket socketServidor = new DatagramSocket(9876); 
      
      System.out.println("Servidor UDP rodando na porta" + socketServidor.getLocalPort());
  
      //byte[] dadosRecebidos = new byte[1024]; 
      //byte[] dadosEnviados  = new byte[1024]; 
  
      while(true) 
        { 
            byte[] dadosRecebidos = new byte[1024]; 
            byte[] dadosEnviados  = new byte[1024]; 
          
            
            DatagramPacket pacoteRecebido = 
             new DatagramPacket(dadosRecebidos, 
		dadosRecebidos.length); 
             socketServidor.receive(pacoteRecebido); 

          String frase = new String(pacoteRecebido.getData()); 
  
          InetAddress IPAddress = pacoteRecebido.getAddress(); 
  
          int porta = pacoteRecebido.getPort(); 
  
          System.out.println("Cliente UDP com IP =" + IPAddress 
                   + " na porta " + porta + 
                   " enviou: " + frase);
          
          String fraseEmMaiusculas = frase.toUpperCase(); 

          dadosEnviados = fraseEmMaiusculas.getBytes(); 
  
          DatagramPacket pacoteEnviado = 
             new DatagramPacket(dadosEnviados, 
                        dadosEnviados.length, IPAddress, porta); 
  
          socketServidor.send(pacoteEnviado); 
        } 
    } 
}  

