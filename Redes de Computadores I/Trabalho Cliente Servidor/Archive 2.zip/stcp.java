/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */


import java.io.*; 
import java.net.*; 

public class stcp { 

  public static void main(String argv[]) throws Exception 
    { 
      String fraseCliente; 
      String fraseEmMaiusculas; 

      ServerSocket socketRecepcao = new ServerSocket(6789); 
  
      while(true) { 
  
            Socket socketConexao = socketRecepcao.accept(); 

            System.out.println("Cliente com IP =" + socketConexao.getInetAddress() 
                   + " está conectado na porta " + socketConexao.getPort());
            
           BufferedReader doCliente = 
              new BufferedReader(new
              InputStreamReader(socketConexao.getInputStream())); 


           DataOutputStream  paraCliente = 
             new DataOutputStream(socketConexao.getOutputStream()); 

           fraseCliente= doCliente.readLine(); 
           
           System.out.println("Cliente com IP =" + socketConexao.getInetAddress() 
                   + " na porta " + socketConexao.getPort() + 
                   " enviou: " + fraseCliente); 

           fraseEmMaiusculas= fraseCliente.toUpperCase() + '\n'; 

           paraCliente.writeBytes(fraseEmMaiusculas); 
        } 
    } 
} 
 
