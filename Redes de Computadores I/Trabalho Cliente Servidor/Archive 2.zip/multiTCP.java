
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author celio
 */

import java.io.*; 
import java.net.*; 

class multiTCP { 

  public static void main(String argv[]) throws Exception 
    { 
      String fraseCliente; 
      String fraseEmMaiusculas; 

      ServerSocket socketRecepcao = new ServerSocket(6789); 
  
      while(true) { 
  
            Socket s = socketRecepcao.accept(); 

            System.out.println("Cliente com IP =" + s.getInetAddress() 
                   + " está conectado na porta " + s.getPort());
            
            EchoTCPMaiusculo cliente = new EchoTCPMaiusculo();
                cliente.setSocketConexao(s);
                Thread threadDoCliente = new Thread(cliente);
                threadDoCliente.start();
            
        } 
    }
}
